import pandas as pd
import numpy as np
import torch
from torch import nn
from sklearn.feature_extraction.text import CountVectorizer
from scipy.spatial.distance import mahalanobis

# Check if GPU is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device)
# Load dataset from CSV files
dataset1 = pd.read_csv('SC_Datasets_noNaN - 副本 - 副本.csv')
dataset2 = pd.read_csv('SC_Datasets_noNaN - 副本.csv')
# Extract required columns
columns = ['file', 'opcode', 'denial_service', 'arithmetic', 'access_control', 'reentrancy', 'time_manipulation']
dataset1 = dataset1[columns]
dataset2 = dataset2[columns]
# Combine the datasets
combined_dataset = pd.concat([dataset1, dataset2], ignore_index=True)
# Convert 'opcode' column to numerical vectors
vectorizer = CountVectorizer()
opcode_vectors = vectorizer.fit_transform(combined_dataset['opcode']).toarray()
# Replace 'opcode' column with numerical vectors
combined_dataset = combined_dataset.drop('opcode', axis=1)
combined_dataset = pd.concat([combined_dataset, pd.DataFrame(opcode_vectors)], axis=1)
# Prepare data and labels
X = combined_dataset.drop('file', axis=1).values
y = np.concatenate((np.zeros(len(dataset1)), np.ones(len(dataset2))))
# Convert data to PyTorch tensors and move to GPU
X = torch.tensor(X, dtype=torch.float32).to(device)
y = torch.tensor(y, dtype=torch.float32).to(device)


def calculate_similarity(X, y, k, learn_rate):
    # Define a custom metric learning model using PyTorch
    class MetricLearningModel(nn.Module):
        def __init__(self, input_dim, output_dim):
            super(MetricLearningModel, self).__init__()
            self.fc = nn.Linear(input_dim, output_dim)

        def forward(self, x):
            return self.fc(x)

    # Create an instance of the metric learning model
    model = MetricLearningModel(X.shape[1], k).to(device)
    criterion = nn.TripletMarginLoss(margin=1.0)  # Triplet margin loss for metric learning
    optimizer = torch.optim.Adam(model.parameters(), lr=learn_rate)
    # Train the model
    num_epochs = 100
    for epoch in range(num_epochs):
        optimizer.zero_grad()
        embeddings = model(X)
        loss = criterion(embeddings, y)
        loss.backward()
        optimizer.step()
    # Compute similarity using Mahalanobis distance
    embeddings = model(X).detach().cpu().numpy()
    mahalanobis_distance_matrix = np.zeros((len(X), len(X)))
    for i in range(len(X)):
        for j in range(len(X)):
            mahalanobis_distance_matrix[i, j] = mahalanobis(
                embeddings[i], embeddings[j], np.eye(X.shape[1]))
    normalized_distance_matrix = (mahalanobis_distance_matrix - np.min(mahalanobis_distance_matrix)) / (
            np.max(mahalanobis_distance_matrix) - np.min(mahalanobis_distance_matrix))


    similarity = 1 - np.mean(normalized_distance_matrix)
    # Analyze the distance matrix and adjust outliers
    threshold = np.percentile(mahalanobis_distance_matrix, 95)  # Set threshold for outliers
    outliers = np.argwhere(mahalanobis_distance_matrix > threshold)  # Find outliers
    for outlier in outliers:
        i, j = outlier[0], outlier[1]
        # Adjust distance values of outliers
        mahalanobis_distance_matrix[i, j] = np.mean(mahalanobis_distance_matrix[i, j])
    normalized_distance_matrix = (mahalanobis_distance_matrix - np.min(mahalanobis_distance_matrix)) / (
            np.max(mahalanobis_distance_matrix) - np.min(mahalanobis_distance_matrix))
    adjusted_similarity = 1 - np.mean(normalized_distance_matrix)
    return similarity, adjusted_similarity

# Parameter settings
best_similarity = 0
best_k = 0
best_learn_rate = 0

# Try different parameter combinations
for k in [3, 5, 7, 9]:
    for learn_rate in [1e-3, 1e-4, 1e-5, 1e-6]:
        similarity, adjusted_similarity = calculate_similarity(X, y, k, learn_rate)
        if adjusted_similarity > best_similarity:
            best_similarity = adjusted_similarity
            best_k = k
            best_learn_rate = learn_rate

# Write the results to the result.txt file
with open('result.txt', 'w') as file:
    file.write("Best parameter combination: k = {}, learn_rate = {}\n".format(best_k, best_learn_rate))
    file.write("Best similarity: {}".format(best_similarity))
print("Results have been written to the result.txt file.")
