import pandas as pd
import numpy as np
from metric_learn import LMNN
from sklearn.feature_extraction.text import CountVectorizer

# Load the datasets from CSV files
dataset1 = pd.read_csv('SC_Datasets_noNaN - 副本 - 副本.csv')
dataset2 = pd.read_csv('SC_Datasets_noNaN - 副本.csv')
# Extract the required columns
columns = ['file', 'opcode', 'denial_service', 'arithmetic', 'access_control', 'reentrancy', 'time_manipulation']
dataset1 = dataset1[columns]
dataset2 = dataset2[columns]
# Combine both datasets
combined_dataset = pd.concat([dataset1, dataset2], ignore_index=True)
# Convert 'opcode' column to numerical vectors
vectorizer = CountVectorizer()
opcode_vectors = vectorizer.fit_transform(combined_dataset['opcode']).toarray()
# Replace 'opcode' column with numerical vectors
combined_dataset = combined_dataset.drop('opcode', axis=1)
combined_dataset = pd.concat([combined_dataset, pd.DataFrame(opcode_vectors)], axis=1)
# Prepare the data and labels
X = combined_dataset.drop('file', axis=1).values
y = np.concatenate((np.zeros(len(dataset1)), np.ones(len(dataset2))))

best_similarity = 0
best_k = None
best_learn_rate = None

# Define the range of values for k and learn_rate
k_values = [1, 3, 5, 7, 9]  # example values, you can adjust as needed
learn_rate_values = [1e-6, 1e-5, 1e-4, 1e-3]  # example values, you can adjust as needed

# Iterate over all combinations of k and learn_rate values
for k in k_values:
    for learn_rate in learn_rate_values:
        # Apply LMNN for metric learning
        lmnn = LMNN(k=k, learn_rate=learn_rate)
        lmnn.fit(X, y)
        # Compute the similarity between the datasets
        distance_matrix = lmnn.transform(X)
        similarity = np.mean(distance_matrix)

        # Check if the current combination is the best so far
        if similarity > best_similarity:
            best_similarity = similarity
            best_k = k
            best_learn_rate = learn_rate

# Print the best combination of parameters and its corresponding similarity
print("Best parameters: k =", best_k, ", learn_rate =", best_learn_rate)
print("Best similarity:", best_similarity)
