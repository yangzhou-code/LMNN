import pandas as pd
import numpy as np
from metric_learn import LMNN, ITML, NCA
from sklearn.feature_extraction.text import CountVectorizer
from scipy.spatial.distance import mahalanobis

# 从CSV文件加载数据集
dataset1 = pd.read_csv('SC_Datasets_noNaN - 副本 - 副本.csv')
dataset2 = pd.read_csv('SC_Datasets_noNaN - 副本.csv')

# 提取所需列
columns = ['file', 'opcode', 'denial_service', 'arithmetic', 'access_control', 'reentrancy', 'time_manipulation']
dataset1 = dataset1[columns]
dataset2 = dataset2[columns]

# 合并两个数据集
combined_dataset = pd.concat([dataset1, dataset2], ignore_index=True)

# 将'opcode'列转换为数值向量
vectorizer = CountVectorizer()
opcode_vectors = vectorizer.fit_transform(combined_dataset['opcode']).toarray()

# 用数值向量替代'opcode'列
combined_dataset = combined_dataset.drop('opcode', axis=1)
combined_dataset = pd.concat([combined_dataset, pd.DataFrame(opcode_vectors)], axis=1)

# 准备数据和标签
X = combined_dataset.drop('file', axis=1).values
y = np.concatenate((np.zeros(len(dataset1)), np.ones(len(dataset2))))


def calculate_similarity(X, y, k, learn_rate):
    # 应用LMNN进行度量学习
    lmnn = LMNN(k=k, learn_rate=learn_rate)
    lmnn.fit(X, y)

    # 计算数据集之间的相似度
    transformer_matrix = lmnn.transform(X)
    mahalanobis_distance_matrix = np.zeros((len(X), len(X)))

    for i in range(len(X)):
        for j in range(len(X)):
            mahalanobis_distance_matrix[i, j] = mahalanobis(
                transformer_matrix[i], transformer_matrix[j], np.eye(X.shape[1]))

    normalized_distance_matrix = (mahalanobis_distance_matrix - np.min(mahalanobis_distance_matrix)) / (
            np.max(mahalanobis_distance_matrix) - np.min(mahalanobis_distance_matrix))
    similarity = 1 - np.mean(normalized_distance_matrix)

    # 分析距离矩阵并调整异常样本
    threshold = np.percentile(mahalanobis_distance_matrix, 95)  # 设置异常值的阈值

    outliers = np.argwhere(mahalanobis_distance_matrix > threshold)  # 找到异常样本
    for outlier in outliers:
        i, j = outlier[0], outlier[1]
        # 调整异常样本的距离值
        mahalanobis_distance_matrix[i, j] = np.mean(mahalanobis_distance_matrix[i, j])

    normalized_distance_matrix = (mahalanobis_distance_matrix - np.min(mahalanobis_distance_matrix)) / (
            np.max(mahalanobis_distance_matrix) - np.min(mahalanobis_distance_matrix))
    adjusted_similarity = 1 - np.mean(normalized_distance_matrix)

    return similarity, adjusted_similarity


# 参数设置
best_similarity = 0
best_k = 0
best_learn_rate = 0

# 尝试不同的参数组合
for k in [3, 5, 7, 9]:
    for learn_rate in [1e-3, 1e-4, 1e-5, 1e-6]:
        similarity, adjusted_similarity = calculate_similarity(X, y, k, learn_rate)

        if adjusted_similarity > best_similarity:
            best_similarity = adjusted_similarity
            best_k = k
            best_learn_rate = learn_rate

# 将结果写入result.txt文件
with open('result.txt', 'w') as file:
    file.write("最好的参数对: k = {}, learn_rate = {}\n".format(best_k, best_learn_rate))
    file.write("最好的相似度: {}".format(best_similarity))

print("结果已写入result.txt文件中")
