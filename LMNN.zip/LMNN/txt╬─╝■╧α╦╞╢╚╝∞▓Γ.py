import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load the text files
file1 = open('文本 - 副本.txt', 'r', encoding='utf-8')
file2 = open('文本.txt', 'r', encoding='utf-8')
text1 = file1.read()
text2 = file2.read()
# Create a dataframe with the text data
data = pd.DataFrame({'text': [text1, text2]})
# Convert text data to numerical vectors
vectorizer = CountVectorizer()
text_vectors = vectorizer.fit_transform(data['text']).toarray()
# Compute the similarity between the text files
similarity_matrix = cosine_similarity(text_vectors)
similarity_percentage = similarity_matrix[0, 1] * 100
print(f"The percentage of similarity between the text files is: {similarity_percentage:.2f}%")
