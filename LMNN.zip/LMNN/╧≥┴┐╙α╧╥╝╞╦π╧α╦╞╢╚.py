import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# 读取两个csv文件
dataset1 = pd.read_csv('SC_Datasets_noNaN - 副本.csv')
dataset2 = pd.read_csv('SC_Datasets_noNaN - 副本 - 副本.csv')

# 提取所需列
columns = ['file', 'opcode', 'denial_service', 'arithmetic', 'access_control', 'reentrancy', 'time_manipulation']
dataset1 = dataset1[columns]
dataset2 = dataset2[columns]

# 合并两个数据集
combined_dataset = pd.concat([dataset1, dataset2], ignore_index=True)

vectorizer = TfidfVectorizer()
opcode_vectors = vectorizer.fit_transform(combined_dataset['opcode']).toarray()

# 删除 'opcode' 列并将数值向量添加到数据集中
combined_dataset = combined_dataset.drop('opcode', axis=1)
combined_dataset = pd.concat([combined_dataset, pd.DataFrame(opcode_vectors)], axis=1)

# 准备数据和标签
X = combined_dataset.drop('file', axis=1).values

# 计算数据集之间的相似度
similarity = cosine_similarity(X)[0][1]

print("Similarity between the files: ", similarity)
